<template>
  <div class="border">
    <div class="bg-white p-10 mb-5">
      <h3 class="font-extrabold text-xl">퍼센트 비율 값 계산</h3>
      <p>값은 숫자만 입력해주세요.</p>
      <input type="text" @input="bindNumber" @change="UpdateCalc" v-model="calc1" class="border rounded p-2 text-right" placeholder="전체값 100"> <span class="mr-2">의</span>
      <input type="text" @change="UpdateCalc" v-model="calc2" class="border rounded p-2 text-right" placeholder="비율값 20"> <span class="mr-2">%는</span>
      <input type="text" :value="ResultCalcA" readonly class="border rounded p-2 text-right" placeholder="일부값 20"> <span>입니다.</span>
    </div>
    <div class="bg-white p-10 mb-5">
      <h3 class="font-extrabold text-xl">일정 값 비율 계산</h3>
      <p>값은 숫자만 입력해주세요.</p>
      <input type="text" v-model="calc3" class="border rounded p-2 text-right" placeholder="전체값 100"> <span class="mr-2">의</span>
      <input type="text" v-model="calc4" class="border rounded p-2 text-right" placeholder="일부값 20"> <span class="mr-2">은(는)</span>
      <input type="text" :value="ResultCalcB" readonly class="border rounded p-2 text-right" placeholder="비율값 20"> <span>%입니다.</span>
      <span class="text-xs ml-4">소수점 자리</span>
      <select v-model="sosu" class="text-xs">
        <option v-for="e in 5" :key="e" :value="e">{{ e }}</option>
      </select>
    </div>
    <div class="bg-white p-10 mb-5">
      <h3 class="font-extrabold text-xl">변경값 비율 계산</h3>
      <p>값은 숫자만 입력해주세요.</p>
      <input type="text" v-model="calc5" class="border rounded p-2 text-right" placeholder="기준값 100"> <span class="mr-2">이(가)</span>
      <input type="text" v-model="calc6" class="border rounded p-2 text-right" placeholder="변경값 20"> <span class="mr-2">로 변경되면</span>
      <input type="text" :value="ResultCalcC" readonly class="border rounded p-2 text-right" placeholder="80% 감소"> <span>입니다.</span>
    </div>
    <div class="bg-white p-10 mb-5 flex flex-wrap items-start">
      <div class="w-full">
        <h3 class="font-extrabold text-xl">기존 > 변경값 비율 계산</h3>
        <p>값은 숫자만 입력해주세요.</p>
      </div>
      <div>
        <input type="text" v-model="calc7" class="border rounded p-2 text-right"> <span class="mr-2">값이</span>
        <input type="text" v-model="calc8" class="border rounded p-2 text-right"> <span class="mr-2">% 변경될 시</span>
      </div>
      <div class="flex flex-col ml-10">
        <div>
          <span class="mr-2">증가값 : </span>
          <input type="text" :value="ResultCalcD" readonly class="border rounded p-2 text-right"> <span>입니다.</span>
        </div>
        <div>
          <span class="mr-2">감소값 : </span>
          <input type="text" :value="ResultCalcE" readonly class="border rounded p-2 text-right"> <span>입니다.</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      calc1:'',
      calc2:'',
      calc3:'',
      calc4:'',
      calc5:'',
      calc6:'',
      calc7:'',
      calc8:'',
      sosu:'2'
    }
  },
  methods: {
    UpdateCalc(){
      console.log('aa');
    },
    bindNumber(e){
      this.calc1 = e.target.value;
    }
  },
  computed:{
    ResultCalcA(){
      return this.calc1 === '' || this.calc2 === '' ? '': (Number(this.calc1)*Number((this.calc2)/100)).toFixed(this.sosu) ;
// v-model은 숫자건 뭐건 문자열로 취급하는 습성이 있다...
    },
    ResultCalcB(){
      return this.calc3 === '' || this.calc4 === '' ? '': ((100*Number(this.calc4))/Number(this.calc3)).toFixed(this.sosu);
    },
    ResultCalcC(){
      let a = (Number(this.calc6)-Number(this.calc5))/Number(this.calc5)*100;
      return this.calc5 === '' || this.calc6 === '' ? '': a >0 ? a.toFixed(0)+'% 증가' : (a*-1).toFixed(0)+'% 감소' 
    },
    ResultCalcD(){
      let d = Number(this.calc7)+(Number(this.calc7)*Number(this.calc8)/100);
      return this.calc7 === '' || this.calc8 === '' ? '': d.toFixed(2); 
    },
    ResultCalcE(){
      let e = Number(this.calc7)-(Number(this.calc7)*Number(this.calc8)/100);
      return this.calc7 === '' || this.calc8 === '' ? '': e.toFixed(2); 
    }
  },
  watch:{
    calc1 : function() {
      return this.calc1 = this.calc1.replace(/[^0-9]/g, '')      
    },
    calc2 : function() {
      return this.calc2 = this.calc2.replace(/[^0-9]/g, '')      
    }
  }, // watch는 요소 자체를 바로 감시하는 역할이다!
  components: {
  }
}
</script>

<style>

</style>
